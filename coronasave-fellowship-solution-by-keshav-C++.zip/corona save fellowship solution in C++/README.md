# CoronaSafe Engineering Fellowship Test Solution

## Steps to follow :

1. Just run the solution.cpp code in any online editor (https://kapwi.ng/c/msAbUNr9 - I used Online GDB Complier in the video)
2. We can get the output


## Solution Video 
[Todo list CPP](https://kapwi.ng/c/msAbUNr9)

## Sorry to Say

I am not good in creating programms and the Readme.md always confuses me..then that npm install, todo.test.js, todo.bat, shell commands etc all are very confusing as I have not much knowlege in it.
I have written the code by myself as much as I can do after understanding this question prompt. I know it not the required solution..but sadly it has been 2 days I was trying to figure the solution out.. as only first 20 codes would be judged with sincere feedback i don't want to delay.. h

Hoping for the positive response and the way how to get the things done with "CLI".. hope you will teach me how to do these kind of work.

Thankyou
Your Obdiently
Keshav CSE-IPU
